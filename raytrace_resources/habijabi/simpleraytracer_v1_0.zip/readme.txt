

Simple ray tracer
-----------------

version 1.0, April 2004
-----------------------


This is supposed to be a very simple, minimal raytracer, mainly for educational purposes.



Building
--------
There is a MSVC++ 6.0 workspace included - the file /simpleraytracer/winsimpleraytracer.dsw.

Hopefully u should be able to build the project from this: if not you can always run the 
executable.

Build it in release mode for optimum speed. 



If you are interested in this, you might want to check out my real-time OpenGL 
accelerated raytracer at 

http://homepages.paradise.net.nz/nickamy/raytracer/raytracer.htm


License
-------
Code by Nicholas Chapman, nickamy@paradise.net.nz

You may use this code for any non-commercial project,
as long as you do not remove this description.

You may *not* use this code for any commercial project.
-------


by Nicholas Chapman
-------------------

nickamy@paradise.net.nz

http://homepages.paradise.net.nz/nickamy/